 [
  {
    Date: "01/01/2024",
    Business Name: "Starbucks",
    Category: "Food & Beverage",
    Amount: 5.75
  },
  {
    Date: "02/01/2024",
    Business Name: "Amazon",
    Category: "Retail & Shopping",
    Amount: 52.99
  },
  {
    Date: "03/01/2024",
    Business Name: "Whole Foods",
    Category: "Home & Personal Care",
    Amount: 78.4
  },
  {
    Date: "04/01/2024",
    Business Name: "Shell",
    Category: "Travel & Transportation",
    Amount: 40
  },
  {
    Date: "05/01/2024",
    Business Name: "Netflix",
    Category: "Entertainment & Subscriptions",
    Amount: 15.99
  },
  {
    Date: "06/01/2024",
    Business Name: "Uber",
    Category: "Travel & Transportation",
    Amount: 12.5
  },
  {
    Date: "07/01/2024",
    Business Name: "Walmart",
    Category: "Retail & Shopping",
    Amount: 45.2
  },
  {
    Date: "08/01/2024",
    Business Name: "Best Buy",
    Category: "Retail & Shopping",
    Amount: 299.99
  },
  {
    Date: "09/01/2024",
    Business Name: "Target",
    Category: "Retail & Shopping",
    Amount: 65.3
  },
  {
    Date: "10/01/2024",
    Business Name: "Chipotle",
    Category: "Food & Beverage",
    Amount: 22.1
  },
  {
    Date: "01/02/2024",
    Business Name: "Spotify",
    Category: "Entertainment & Subscriptions",
    Amount: 9.99
  },
  {
    Date: "02/02/2024",
    Business Name: "Home Depot",
    Category: "Home & Personal Care",
    Amount: 150
  },
  {
    Date: "03/02/2024",
    Business Name: "Dunkin' Donuts",
    Category: "Food & Beverage",
    Amount: 4.5
  },
  {
    Date: "04/02/2024",
    Business Name: "Airbnb",
    Category: "Travel & Transportation",
    Amount: 120
  },
  {
    Date: "05/02/2024",
    Business Name: "Apple Store",
    Category: "Retail & Shopping",
    Amount: 999.99
  },
  {
    Date: "06/02/2024",
    Business Name: "Costco",
    Category: "Home & Personal Care",
    Amount: 200
  },
  {
    Date: "07/02/2024",
    Business Name: "Subway",
    Category: "Food & Beverage",
    Amount: 8.75
  },
  {
    Date: "08/02/2024",
    Business Name: "CVS",
    Category: "Home & Personal Care",
    Amount: 25.6
  },
  {
    Date: "09/02/2024",
    Business Name: "Sephora",
    Category: "Home & Personal Care",
    Amount: 35.4
  },
  {
    Date: "10/02/2024",
    Business Name: "Petco",
    Category: "Home & Personal Care",
    Amount: 49.99
  },
  {
    Date: "01/03/2024",
    Business Name: "Panera Bread",
    Category: "Food & Beverage",
    Amount: 16.2
  },
  {
    Date: "02/03/2024",
    Business Name: "Delta Airlines",
    Category: "Travel & Transportation",
    Amount: 250
  },
  {
    Date: "03/03/2024",
    Business Name: "IKEA",
    Category: "Retail & Shopping",
    Amount: 130
  },
  {
    Date: "04/03/2024",
    Business Name: "McDonald's",
    Category: "Food & Beverage",
    Amount: 7.89
  },
  {
    Date: "05/03/2024",
    Business Name: "Walgreens",
    Category: "Home & Personal Care",
    Amount: 13.75
  },
  {
    Date: "06/03/2024",
    Business Name: "Zara",
    Category: "Retail & Shopping",
    Amount: 85
  },
  {
    Date: "07/03/2024",
    Business Name: "Trader Joe's",
    Category: "Retail & Shopping",
    Amount: 54.3
  },
  {
    Date: "08/03/2024",
    Business Name: "Microsoft",
    Category: "Entertainment & Subscriptions",
    Amount: 120
  },
  {
    Date: "09/03/2024",
    Business Name: "GameStop",
    Category: "Entertainment & Subscriptions",
    Amount: 60
  },
  {
    Date: "10/03/2024",
    Business Name: "Marriott",
    Category: "Travel & Transportation",
    Amount: 200
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "",
    Business Name: "",
    Category: "",
    Amount: ""
  },
  {
    Date: "01/06/2024",
    Business Name: "Panera Bread",
    Category: "Food & Beverage",
    Amount: 18
  },
  {
    Date: "02/06/2024",
    Business Name: "Delta Airlines",
    Category: "Travel & Transportation",
    Amount: 300
  },
  {
    Date: "03/06/2024",
    Business Name: "IKEA",
    Category: "Retail & Shopping",
    Amount: 140
  },
  {
    Date: "04/06/2024",
    Business Name: "McDonald's",
    Category: "Food & Beverage",
    Amount: 8.5
  },
  {
    Date: "05/06/2024",
    Business Name: "Walgreens",
    Category: "Home & Personal Care",
    Amount: 15
  },
  {
    Date: "06/06/2024",
    Business Name: "Zara",
    Category: "Retail & Shopping",
    Amount: 95
  },
  {
    Date: "07/06/2024",
    Business Name: "Trader Joe's",
    Category: "Retail & Shopping",
    Amount: 60
  },
  {
    Date: "08/06/2024",
    Business Name: "Microsoft",
    Category: "Entertainment & Subscriptions",
    Amount: 130
  },
  {
    Date: "09/06/2024",
    Business Name: "GameStop",
    Category: "Entertainment & Subscriptions",
    Amount: 65
  },
  {
    Date: "10/06/2024",
    Business Name: "Marriott",
    Category: "Travel & Transportation",
    Amount: 220
  },
  {
    Date: "01/07/2024",
    Business Name: "Starbucks",
    Category: "Food & Beverage",
    Amount: 7
  },
  {
    Date: "02/07/2024",
    Business Name: "Amazon",
    Category: "Retail & Shopping",
    Amount: 80
  },
  {
    Date: "03/07/2024",
    Business Name: "Whole Foods",
    Category: "Home & Personal Care",
    Amount: 85
  },
  {
    Date: "04/07/2024",
    Business Name: "Shell",
    Category: "Travel & Transportation",
    Amount: 60
  },
  {
    Date: "05/07/2024",
    Business Name: "Netflix",
    Category: "Entertainment & Subscriptions",
    Amount: 18.99
  },
  {
    Date: "06/07/2024",
    Business Name: "Uber",
    Category: "Travel & Transportation",
    Amount: 18
  },
  {
    Date: "07/07/2024",
    Business Name: "Walmart",
    Category: "Retail & Shopping",
    Amount: 70
  },
  {
    Date: "08/07/2024",
    Business Name: "Best Buy",
    Category: "Retail & Shopping",
    Amount: 275
  },
  {
    Date: "09/07/2024",
    Business Name: "Target",
    Category: "Retail & Shopping",
    Amount: 80
  },
  {
    Date: "10/07/2024",
    Business Name: "Chipotle",
    Category: "Food & Beverage",
    Amount: 27
  },
  {
    Date: "01/08/2024",
    Business Name: "Spotify",
    Category: "Entertainment & Subscriptions",
    Amount: 12.99
  },
  {
    Date: "02/08/2024",
    Business Name: "Home Depot",
    Category: "Home & Personal Care",
    Amount: 140
  },
  {
    Date: "03/08/2024",
    Business Name: "Dunkin' Donuts",
    Category: "Food & Beverage",
    Amount: 6
  },
  {
    Date: "04/08/2024",
    Business Name: "Airbnb",
    Category: "Travel & Transportation",
    Amount: 140
  },
  {
    Date: "05/08/2024",
    Business Name: "Apple Store",
    Category: "Retail & Shopping",
    Amount: 1100
  },
  {
    Date: "06/08/2024",
    Business Name: "Costco",
    Category: "Home & Personal Care",
    Amount: 190
  },
  {
    Date: "07/08/2024",
    Business Name: "Subway",
    Category: "Food & Beverage",
    Amount: 10
  },
  {
    Date: "08/08/2024",
    Business Name: "CVS",
    Category: "Home & Personal Care",
    Amount: 35
  },
  {
    Date: "09/08/2024",
    Business Name: "Sephora",
    Category: "Home & Personal Care",
    Amount: 45
  },
  {
    Date: "10/08/2024",
    Business Name: "Petco",
    Category: "Home & Personal Care",
    Amount: 60
  },
  {
    Date: "01/09/2024",
    Business Name: "Panera Bread",
    Category: "Food & Beverage",
    Amount: 20
  },
  {
    Date: "02/09/2024",
    Business Name: "Delta Airlines",
    Category: "Travel & Transportation",
    Amount: 320
  },
  {
    Date: "03/09/2024",
    Business Name: "IKEA",
    Category: "Retail & Shopping",
    Amount: 150
  },
  {
    Date: "04/09/2024",
    Business Name: "McDonald's",
    Category: "Food & Beverage",
    Amount: 9
  },
  {
    Date: "05/09/2024",
    Business Name: "Walgreens",
    Category: "Home & Personal Care",
    Amount: 16
  },
  {
    Date: "06/09/2024",
    Business Name: "Zara",
    Category: "Retail & Shopping",
    Amount: 100
  },
  {
    Date: "07/09/2024",
    Business Name: "Trader Joe's",
    Category: "Retail & Shopping",
    Amount: 65
  },
  {
    Date: "08/09/2024",
    Business Name: "Microsoft",
    Category: "Entertainment & Subscriptions",
    Amount: 140
  },
  {
    Date: "09/09/2024",
    Business Name: "GameStop",
    Category: "Entertainment & Subscriptions",
    Amount: 70
  },
  {
    Date: "10/09/2024",
    Business Name: "Marriott",
    Category: "Travel & Transportation",
    Amount: 230
  },
  {
    Date: "01/10/2024",
    Business Name: "Starbucks",
    Category: "Food & Beverage",
    Amount: 8
  },
  {
    Date: "02/10/2024",
    Business Name: "Amazon",
    Category: "Retail & Shopping",
    Amount: 85
  },
  {
    Date: "03/10/2024",
    Business Name: "Whole Foods",
    Category: "Home & Personal Care",
    Amount: 95
  },
  {
    Date: "04/10/2024",
    Business Name: "Shell",
    Category: "Travel & Transportation",
    Amount: 70
  },
  {
    Date: "05/10/2024",
    Business Name: "Netflix",
    Category: "Entertainment & Subscriptions",
    Amount: 19.99
  },
  {
    Date: "06/10/2024",
    Business Name: "Uber",
    Category: "Travel & Transportation",
    Amount: 20
  },
  {
    Date: "07/10/2024",
    Business Name: "Walmart",
    Category: "Retail & Shopping",
    Amount: 80
  },
  {
    Date: "08/10/2024",
    Business Name: "Best Buy",
    Category: "Retail & Shopping",
    Amount: 290
  },
  {
    Date: "09/10/2024",
    Business Name: "Target",
    Category: "Retail & Shopping",
    Amount: 90
  },
  {
    Date: "10/10/2024",
    Business Name: "Chipotle",
    Category: "Food & Beverage",
    Amount: 30
  },
  {
    Date: "01/11/2024",
    Business Name: "Spotify",
    Category: "Entertainment & Subscriptions",
    Amount: 13.99
  },
  {
    Date: "02/11/2024",
    Business Name: "Home Depot",
    Category: "Home & Personal Care",
    Amount: 160
  },
  {
    Date: "03/11/2024",
    Business Name: "Dunkin' Donuts",
    Category: "Food & Beverage",
    Amount: 6.5
  },
  {
    Date: "04/11/2024",
    Business Name: "Airbnb",
    Category: "Travel & Transportation",
    Amount: 150
  },
  {
    Date: "05/11/2024",
    Business Name: "Apple Store",
    Category: "Retail & Shopping",
    Amount: 1150
  },
  {
    Date: "06/11/2024",
    Business Name: "Costco",
    Category: "Home & Personal Care",
    Amount: 200
  },
  {
    Date: "07/11/2024",
    Business Name: "Subway",
    Category: "Food & Beverage",
    Amount: 11
  },
  {
    Date: "08/11/2024",
    Business Name: "CVS",
    Category: "Home & Personal Care",
    Amount: 40
  },
  {
    Date: "09/11/2024",
    Business Name: "Sephora",
    Category: "Home & Personal Care",
    Amount: 50
  },
  {
    Date: "10/11/2024",
    Business Name: "Petco",
    Category: "Home & Personal Care",
    Amount: 65
  },
  {
    Date: "01/12/2024",
    Business Name: "Panera Bread",
    Category: "Food & Beverage",
    Amount: 21
  },
  {
    Date: "02/12/2024",
    Business Name: "Delta Airlines",
    Category: "Travel & Transportation",
    Amount: 340
  },
  {
    Date: "03/12/2024",
    Business Name: "IKEA",
    Category: "Retail & Shopping",
    Amount: 160
  },
  {
    Date: "04/12/2024",
    Business Name: "McDonald's",
    Category: "Food & Beverage",
    Amount: 9.5
  },
  {
    Date: "05/12/2024",
    Business Name: "Walgreens",
    Category: "Home & Personal Care",
    Amount: 17
  },
  {
    Date: "06/12/2024",
    Business Name: "Zara",
    Category: "Retail & Shopping",
    Amount: 105
  },
  {
    Date: "07/12/2024",
    Business Name: "Trader Joe's",
    Category: "Retail & Shopping",
    Amount: 70
  },
  {
    Date: "08/12/2024",
    Business Name: "Microsoft",
    Category: "Entertainment & Subscriptions",
    Amount: 150
  },
  {
    Date: "09/12/2024",
    Business Name: "GameStop",
    Category: "Entertainment & Subscriptions",
    Amount: 75
  },
  {
    Date: "10/12/2024",
    Business Name: "Marriott",
    Category: "Travel & Transportation",
    Amount: 240
  }
]